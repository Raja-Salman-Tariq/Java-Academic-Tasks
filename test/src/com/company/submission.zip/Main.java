package com.company;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        IntSet a = new EmptySet();
        System.out.println(a.toString());

        a=a.add(12);
        System.out.println(a.toString());

        a=a.add(12);                    // NO DUPLICATES OCCURING
        System.out.println(a.toString());
    }
}



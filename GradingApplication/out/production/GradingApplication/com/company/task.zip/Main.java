package com.company;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Grader g=new Grader();
        g.OpenFile();

//        ArrayList<Student> s;

        g.readResultFile();
        g.readKeyFile();

        g.gradeCalculation();
    }
}

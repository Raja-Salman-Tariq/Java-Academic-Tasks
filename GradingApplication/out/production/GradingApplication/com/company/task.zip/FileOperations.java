package com.company;

public interface FileOperations {
	public void OpenFile();
	public void readResultFile();
	public void readKeyFile();
	public void writeResultFile();
	public void closeFile();
}

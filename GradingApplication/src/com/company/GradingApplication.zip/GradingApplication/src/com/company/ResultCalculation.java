package com.company;

public interface ResultCalculation {
	public void gradeCalculation();
}

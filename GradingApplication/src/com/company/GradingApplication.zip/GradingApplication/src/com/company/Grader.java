package com.company;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Grader implements FileOperations, ResultCalculation {
	File file, file1;
	String dirPath="src/com/company/";
	String[] ansKey;

	public Grader() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void gradeCalculation() {
		// TODO Auto-generated method stub

	}

	@Override
	public void OpenFile() {
		// TODO Auto-generated method stub
		file = new File(dirPath+"key.txt");
		try {
			Scanner input1 = new Scanner(file);
			System.out.println("Success opening key");

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error opening key");
		}
		file1 = new File(
				dirPath+"result.txt");
		try {
			Scanner input2 = new Scanner(file1);
			System.out.println("Success opening result");

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error opening result");

		}
	}

	@Override
	public void readResultFile() {
		// TODO Auto-generated method stub
		Scanner s=null;
		try {
			s=new Scanner(file1);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Scanner loading result failed");
		}

		ArrayList<Student> stds=new ArrayList<>();

		String n, reg, holder;
		ArrayList<String> ans=new ArrayList<>();

		StringTokenizer tokenizer;

		while (s.hasNextLine()){
			tokenizer=new StringTokenizer(s.nextLine());
			n=tokenizer.nextToken();
			reg=tokenizer.nextToken();

			holder=tokenizer.nextToken();
			while (!holder.equals("")){
//				if (holder.equals('\n') | holder.equals("\r\n") | holder.equals('\r'))
//					System.out.println("Horror***********");
//				else
				ans.add(holder);
				if (tokenizer.hasMoreTokens())
					holder=tokenizer.nextToken();
				else
					break;
			}

			stds.add(new Student(n, reg, ans));
			ans.clear();
		}

//		for (Student std: stds
//			 ) {
//
//			System.out.println(std.toString());
//
//		}


//		File file1 = new File(
//				dirPath+"result.txt");
//		Student student[] = new Student[2];
//		student[0] = new Student();
//		student[1] = new Student();
//
//		try {
//			Scanner input2 = new Scanner(file1);
//			int count = 0;
//			while (input2.hasNextLine()) {
//				String word = input2.nextLine();
//				String[] words = word.split("[ ']");
//				for (int i = 0; i < words.length; i++) {
//					student[count].setName(words[i]);
//				}
//				count += 1;
//
//			}
//
//			System.out.println("count" + count);
//
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}

	@Override
	public void readKeyFile() {
		// TODO Auto-generated method stub
		Scanner s=null;
		try {
			s=new Scanner(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Scanner loading key failed");
		}

		int sz=(s.nextInt());
		ansKey=new String[sz];
		int i=0;
		while (s.hasNextLine()){
			ansKey[i++]=s.next();
		}

//		System.out.println("ok sooooooo************"+ Arrays.toString(ansKey));

//		String holder;
//		ArrayList<String> ans=new ArrayList<>();
//
//		StringTokenizer tokenizer;
//
//		while (s.hasNextLine()){
//			tokenizer=new StringTokenizer(s.nextLine());
//			n=tokenizer.nextToken();
//			reg=tokenizer.nextToken();
//
//			holder=tokenizer.nextToken();
//			while (!holder.equals("")){
////				if (holder.equals('\n') | holder.equals("\r\n") | holder.equals('\r'))
////					System.out.println("Horror***********");
////				else
//				ans.add(holder);
//				if (tokenizer.hasMoreTokens())
//					holder=tokenizer.nextToken();
//				else
//					break;
//			}
//
//			stds.add(new Student(n, reg, ans));
//			ans.clear();
//		}

	}

	@Override
	public void writeResultFile() {
		// TODO Auto-generated method stub

	}

	@Override
	public void closeFile() {
		// TODO Auto-generated method stub

	}

	public static void main(String[] args) {
		Grader d = new Grader();
		d.readResultFile();
	}
}

package com.company;

public class FailException {

	public FailException() {
		// TODO Auto-generated constructor stub
	}

}
